package com.javatpoint.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.javatpoint.beans.Login;
import com.javatpoint.beans.User;
import com.javatpoint.service.UserService;

@Controller
@SessionAttributes("thought")

public class LoginController {
	@Autowired
	UserService userService;
	
	@RequestMapping(value="login", method=RequestMethod.GET)
	public ModelAndView  showLogin(HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("login", new Login());
		return mav;
	}
	@RequestMapping(value="/loginprocess", method=RequestMethod.POST)
	public ModelAndView loginProcess(@Valid HttpServletRequest request, HttpServletResponse response, @ModelAttribute("login") Login login,HttpSession session){
		//ModelAndView mav=null;
		//String username = request.getParameter("username");
	   ModelAndView mav= new ModelAndView();
	   mav.addObject("thought", login);
	   mav.setViewName("login");
		//String password = request.getParameter("password");
		//session.setAttribute("username", username);
        //session.setAttribute("password", password);

		User user= userService.validateUser(login);
		if(null !=user)
		{
			
			mav= new ModelAndView("viewemp");
		
			mav.addObject("firstname", user.getFirstname());
		}
		else{
			mav= new ModelAndView("login");
			mav.addObject("message", "Username and Password is incorrect !!");
			return mav;
		}
		return mav;
	}
	@RequestMapping(value="logout", method= RequestMethod.GET)
	public String logout(HttpSession session)
	{
		//session.removeAttribute("id");
        session.invalidate();
		return "redirect:../digitalmvc";
	}

}
